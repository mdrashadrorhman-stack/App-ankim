import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EarnBdApp());
}

const brand = Color(0xFF087F5B);

class EarnBdApp extends StatelessWidget {
  const EarnBdApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EarnBD',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: brand),
        scaffoldBackgroundColor: const Color(0xFFF6F8F7),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: brand,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: const EarnHome(),
    );
  }
}

class EarnHome extends StatefulWidget {
  const EarnHome({super.key});

  @override
  State<EarnHome> createState() => _EarnHomeState();
}

class _EarnHomeState extends State<EarnHome> {
  int _balance = 0;
  int _totalEarned = 0;
  int _selectedIndex = 0;
  bool _checkedIn = false;
  bool _quizDone = false;
  final List<Map<String, dynamic>> _withdrawals = [];
  final List<String> _activity = [];
  SharedPreferences? _prefs;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _balance = _prefs!.getInt('balance') ?? 0;
      _totalEarned = _prefs!.getInt('totalEarned') ?? 0;
      _checkedIn = _prefs!.getBool('checkedIn') ?? false;
      _quizDone = _prefs!.getBool('quizDone') ?? false;
      _activity.addAll(_prefs!.getStringList('activity') ?? []);
      final saved = _prefs!.getStringList('withdrawals') ?? [];
      for (final item in saved) {
        final parts = item.split('|');
        if (parts.length == 4) {
          _withdrawals.add({
            'method': parts[0],
            'amount': int.tryParse(parts[1]) ?? 0,
            'number': parts[2],
            'status': parts[3],
          });
        }
      }
    });
  }

  Future<void> _save() async {
    final p = _prefs ?? await SharedPreferences.getInstance();
    await p.setInt('balance', _balance);
    await p.setInt('totalEarned', _totalEarned);
    await p.setBool('checkedIn', _checkedIn);
    await p.setBool('quizDone', _quizDone);
    await p.setStringList('activity', _activity.take(30).toList());
    await p.setStringList(
      'withdrawals',
      _withdrawals.map((w) =>
        '${w['method']}|${w['amount']}|${w['number']}|${w['status']}').toList(),
    );
  }

  void _earn(int amount, String reason) {
    setState(() {
      _balance += amount;
      _totalEarned += amount;
      _activity.insert(0, '$reason: +৳$amount');
    });
    _save();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('৳$amount demo reward যোগ হয়েছে')),
    );
  }

  void _checkIn() {
    if (_checkedIn) return;
    setState(() => _checkedIn = true);
    _earn(5, 'দৈনিক চেক-ইন');
  }

  void _takeQuiz() {
    if (_quizDone) return;
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('ছোট কুইজ'),
        content: const Text('বাংলাদেশের রাজধানী কোনটি?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('পরে'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() => _quizDone = true);
              _earn(10, 'কুইজ সম্পন্ন');
            },
            child: const Text('ঢাকা'),
          ),
        ],
      ),
    );
  }

  Future<void> _showWithdrawalForm() async {
    final amountController = TextEditingController();
    final numberController = TextEditingController();
    String method = 'bKash';
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('উত্তোলনের অনুরোধ'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'ডেমো: এই অনুরোধে বাস্তব টাকা পাঠানো হবে না.',
                  style: TextStyle(color: Colors.deepOrange),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: method,
                  decoration: const InputDecoration(labelText: 'পেমেন্ট মাধ্যম'),
                  items: const [
                    DropdownMenuItem(value: 'bKash', child: Text('bKash')),
                    DropdownMenuItem(value: 'Nagad', child: Text('Nagad')),
                  ],
                  onChanged: (v) => setDialogState(() => method = v ?? 'bKash'),
                ),
                TextField(
                  controller: numberController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'মোবাইল নম্বর',
                    hintText: '01XXXXXXXXX',
                  ),
                ),
                TextField(
                  controller: amountController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'পরিমাণ (৳)',
                    hintText: 'কমপক্ষে ৫০',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('বাতিল'),
            ),
            FilledButton(
              onPressed: () {
                final amount = int.tryParse(amountController.text.trim());
                final number = numberController.text.trim();
                if (amount == null || amount < 50) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('কমপক্ষে ৳৫০ লিখুন')),
                  );
                  return;
                }
                if (amount > _balance) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('আপনার ব্যালেন্স যথেষ্ট নয়')),
                  );
                  return;
                }
                if (!RegExp(r'^01[3-9]\d{8}$').hasMatch(number)) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('সঠিক বাংলাদেশি মোবাইল নম্বর দিন')),
                  );
                  return;
                }
                Navigator.pop(context, {
                  'method': method, 'amount': amount, 'number': number,
                });
              },
              child: const Text('অনুরোধ তৈরি করুন'),
            ),
          ],
        ),
      ),
    );

    if (result == null || !mounted) return;
    setState(() {
      _balance -= result['amount'] as int;
      _withdrawals.insert(0, {
        ...result,
        'status': 'Demo pending',
      });
      _activity.insert(0, 'উত্তোলন অনুরোধ: ৳${result['amount']} (${result['method']})');
    });
    await _save();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('ডেমো উত্তোলন অনুরোধ সংরক্ষিত হয়েছে')),
    );
  }

  void _resetDemo() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('ডেমো ডেটা মুছবেন?'),
        content: const Text('ব্যালেন্স, কাজ ও উত্তোলনের ইতিহাস রিসেট হবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('না')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('রিসেট')),
        ],
      ),
    );
    if (ok != true) return;
    await _prefs?.clear();
    if (!mounted) return;
    setState(() {
      _balance = 0; _totalEarned = 0; _checkedIn = false; _quizDone = false;
      _withdrawals.clear(); _activity.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(),
      _tasksPage(),
      _walletPage(),
      _profilePage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.account_balance_wallet_outlined),
            SizedBox(width: 8),
            Text('EarnBD'),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'ডেমো ডেটা রিসেট',
            onPressed: _resetDemo,
            icon: const Icon(Icons.restart_alt),
          ),
        ],
      ),
      body: SafeArea(child: pages[_selectedIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (i) => setState(() => _selectedIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'হোম'),
          NavigationDestination(icon: Icon(Icons.task_alt), label: 'কাজ'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'ওয়ালেট'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'প্রোফাইল'),
        ],
      ),
    );
  }

  Widget _dashboard() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [brand, Color(0xFF12A875)]),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('আপনার ডেমো ব্যালেন্স', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text('৳$_balance', style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: _whiteStat('মোট ডেমো আয়', '৳$_totalEarned')),
            Expanded(child: _whiteStat('পেন্ডিং অনুরোধ', '${_withdrawals.where((w) => w['status'] == 'Demo pending').length}')),
          ]),
          const SizedBox(height: 12),
          const Text('এটি পরীক্ষামূলক ব্যালেন্স; বাস্তব টাকা নয়।', style: TextStyle(color: Colors.white70, fontSize: 12)),
        ]),
      ),
      const SizedBox(height: 20),
      const Text('আজ কী করবেন?', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      _taskTile(Icons.calendar_today, 'দৈনিক চেক-ইন', 'প্রতিদিন ৳৫ ডেমো রিওয়ার্ড', _checkedIn ? 'সম্পন্ন' : 'নিন', _checkIn, disabled: _checkedIn),
      _taskTile(Icons.quiz_outlined, 'কুইজ', 'সঠিক উত্তর দিলে ৳১০ ডেমো রিওয়ার্ড', _quizDone ? 'সম্পন্ন' : 'শুরু', _takeQuiz, disabled: _quizDone),
      _taskTile(Icons.group_add_outlined, 'বন্ধুকে আমন্ত্রণ', 'রেফারেল ফিচার পরবর্তী সংস্করণে', 'শীঘ্রই', () => _info('রেফারেল লিংক, প্রতারণা প্রতিরোধ এবং সার্ভার যাচাই পরবর্তী সংস্করণে যুক্ত হবে।'), disabled: true),
      _taskTile(Icons.ondemand_video, 'বিজ্ঞাপন দেখে আয়', 'অনুমোদিত rewarded ad ইন্টিগ্রেশন প্রয়োজন', 'বিস্তারিত', () => _info('বাস্তব বিজ্ঞাপন থেকে রিওয়ার্ড দেওয়ার আগে বিজ্ঞাপন নেটওয়ার্কের নীতি মেনে rewarded ads এবং সার্ভার-সাইড যাচাই যুক্ত করতে হবে।')),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: () => setState(() => _selectedIndex = 2),
        icon: const Icon(Icons.payments_outlined),
        label: const Text('উত্তোলনের অনুরোধ'),
      ),
    ],
  );

  Widget _tasksPage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('আয়ের কাজ', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('MVP-তে নিচের কাজগুলো ডেমো রিওয়ার্ড ব্যবহার করে।'),
      const SizedBox(height: 16),
      _taskTile(Icons.calendar_month, 'দৈনিক চেক-ইন', 'একবার ৳৫', _checkedIn ? 'সম্পন্ন' : 'রিওয়ার্ড নিন', _checkIn, disabled: _checkedIn),
      _taskTile(Icons.lightbulb_outline, 'সাধারণ জ্ঞান কুইজ', 'একবার ৳১০', _quizDone ? 'সম্পন্ন' : 'কুইজ খেলুন', _takeQuiz, disabled: _quizDone),
      _taskTile(Icons.share_outlined, 'রেফারেল', 'পরবর্তী সংস্করণে', 'বিস্তারিত', () => _info('রেফারেল সিস্টেমে ইউনিক কোড, সার্ভার যাচাই এবং অপব্যবহার প্রতিরোধ যুক্ত করতে হবে।')),
      _taskTile(Icons.ondemand_video, 'Rewarded বিজ্ঞাপন', 'বিজ্ঞাপন SDK যুক্ত করতে হবে', 'বিস্তারিত', () => _info('প্রোডাকশনে বিজ্ঞাপন দেখার সত্যতা সার্ভার-সাইড যাচাই করতে হবে।')),
    ],
  );

  Widget _walletPage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('ওয়ালেট', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Card(child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('বর্তমান ডেমো ব্যালেন্স'),
          Text('৳$_balance', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: brand)),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: _showWithdrawalForm, icon: const Icon(Icons.payments), label: const Text('bKash / Nagad উত্তোলন')),
          const SizedBox(height: 8),
          const Text('ন্যূনতম ৳৫০ • ডেমো মোডে কোনো টাকা পাঠানো হয় না।', style: TextStyle(fontSize: 12, color: Colors.deepOrange)),
        ]),
      )),
      const SizedBox(height: 16),
      const Text('উত্তোলনের ইতিহাস', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (_withdrawals.isEmpty) const _EmptyState(text: 'এখনো কোনো অনুরোধ নেই'),
      ..._withdrawals.map((w) => Card(
        child: ListTile(
          leading: const Icon(Icons.receipt_long),
          title: Text('${w['method']} • ৳${w['amount']}'),
          subtitle: Text('${w['number']} • ${w['status']}'),
          trailing: const Icon(Icons.hourglass_empty, color: Colors.orange),
        ),
      )),
      const SizedBox(height: 16),
      const Text('সাম্প্রতিক কার্যক্রম', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      if (_activity.isEmpty) const _EmptyState(text: 'কোনো কার্যক্রম নেই'),
      ..._activity.take(10).map((a) => ListTile(dense: true, leading: const Icon(Icons.history), title: Text(a))),
    ],
  );

  Widget _profilePage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const CircleAvatar(radius: 36, child: Icon(Icons.person, size: 36)),
      const SizedBox(height: 12),
      const Center(child: Text('ডেমো ব্যবহারকারী', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
      const Center(child: Text('লগইন এখনো যুক্ত করা হয়নি')),
      const SizedBox(height: 20),
      const Card(child: ListTile(leading: Icon(Icons.security), title: Text('অ্যাকাউন্ট নিরাপত্তা'), subtitle: Text('প্রোডাকশনের আগে Firebase Authentication যোগ করুন।'))),
      const Card(child: ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('গোপনীয়তা'), subtitle: Text('বাস্তব ব্যবহারকারীর তথ্য সংগ্রহের আগে Privacy Policy প্রকাশ করুন।'))),
      const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('EarnBD MVP'), subtitle: Text('প্রোটোটাইপ সংস্করণ 1.0.0'))),
      const SizedBox(height: 12),
      OutlinedButton.icon(onPressed: _resetDemo, icon: const Icon(Icons.delete_outline), label: const Text('ডেমো ডেটা রিসেট')),
    ],
  );

  Widget _whiteStat(String label, String value) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
      const SizedBox(height: 4),
      Text(value, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
    ],
  );

  Widget _taskTile(IconData icon, String title, String subtitle, String action, VoidCallback onTap, {bool disabled = false}) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      leading: CircleAvatar(backgroundColor: brand.withOpacity(0.1), child: Icon(icon, color: brand)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle),
      trailing: TextButton(onPressed: disabled ? null : onTap, child: Text(action)),
    ),
  );

  void _info(String message) => showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('পরবর্তী সংস্করণে'),
      content: Text(message),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('ঠিক আছে'))],
    ),
  );
}

class _EmptyState extends StatelessWidget {
  final String text;
  const _EmptyState({required this.text});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(20),
    child: Center(child: Text(text, style: TextStyle(color: Colors.grey.shade600))),
  );
}
