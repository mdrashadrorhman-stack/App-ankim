# EarnBD Flutter MVP

বাংলা ভাষার cross-platform earning-app prototype. একই Flutter codebase থেকে Android ও iOS-এ চালানোর জন্য তৈরি।

## MVP-তে যা কাজ করে
- বাংলা dashboard, balance এবং total demo-earned summary
- দৈনিক check-in demo reward
- একটি সাধারণ quiz demo reward
- bKash/Nagad withdrawal request form (ডেমো)
- local activity এবং withdrawal history persistence
- demo data reset
- responsive Material 3 layout

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি **শুধু লোকাল ডেমো**। দেখানো balance বাস্তব টাকা নয়। bKash/Nagad-এ টাকা পাঠায় না। রেফারেল, rewarded ads, লগইন, Firebase sync, admin approval এবং real payout এখনো সংযুক্ত নয়। লোকাল ডেটা ব্যবহারকারীর ডিভাইসে থাকে এবং অ্যাপ আনইনস্টল/ডেটা ক্লিয়ার হলে হারাতে পারে। প্রোডাকশনে এভাবে reward বা balance বিশ্বাস করবেন না।

## চালানোর জন্য
1. Flutter SDK ইনস্টল করুন: https://docs.flutter.dev/get-started/install
2. Android Studio ইনস্টল করে Android SDK/একটি emulator সেট করুন।
3. ZIP extract করে `EarnBD_MVP` ফোল্ডারে terminal খুলুন।
4. চালান:
   ```bash
   flutter doctor
   flutter pub get
   flutter run
   ```
5. ডিভাইস বাছতে `flutter devices` চালান।

## Android APK তৈরি
```bash
flutter build apk --release
```
ফাইল সাধারণত থাকবে:
`build/app/outputs/flutter-apk/app-release.apk`

## iPhone / iOS build
- macOS কম্পিউটার, Xcode এবং iOS toolchain লাগবে।
- Mac-এ:
  ```bash
  flutter doctor
  flutter pub get
  open ios/Runner.xcworkspace
  flutter run
  ```
- App Store-এ প্রকাশের জন্য Apple Developer account, signing এবং App Store review লাগবে।

## বাস্তব সিস্টেমে যাওয়ার আগে
1. Firebase Authentication যোগ করুন (ফোন/ইমেইল লগইন)।
2. Firestore-এ user, task, reward ledger এবং withdrawal request রাখুন।
3. Reward/withdrawal পরিবর্তন Cloud Functions-এ করুন; ক্লায়েন্ট থেকে সরাসরি balance পরিবর্তন নিষিদ্ধ করুন।
4. Admin panel-এ KYC/abuse checks, withdrawal approval, audit log এবং refund/reversal workflow দিন।
5. bKash/Nagad-এর অনুমোদিত merchant/disbursement integration এবং চুক্তি নিন। সাধারণ ব্যক্তিগত wallet-এ স্বয়ংক্রিয় payout ধরে নেবেন না।
6. Google rewarded ads যুক্ত করলে network policy অনুসরণ করুন এবং ad view যাচাই server-side করুন। ব্যবহারকারীকে বিজ্ঞাপনে ক্লিক করতে পুরস্কৃত করবেন না।
7. Terms, Privacy Policy, minimum withdrawal, fees, eligibility, anti-fraud, support process এবং tax/legal obligations নির্ধারণ করুন।
8. Firebase Security Rules, App Check, rate limits, secrets management এবং production testing সম্পন্ন করুন।

## প্রস্তাবিত Firestore collections
- `users/{uid}`: displayName, createdAt, status
- `rewardLedger/{entryId}`: uid, amount, source, status, createdAt, idempotencyKey
- `withdrawals/{requestId}`: uid, amount, method, payoutNumberMasked, status, createdAt, reviewedAt
- `tasks/{taskId}`: title, type, reward, active, rules
- `referrals/{referralId}`: referrerUid, referredUid, status, createdAt

প্রোডাকশনে `balance`-কে ক্লায়েন্ট থেকে সম্পাদনযোগ্য করবেন না। Ledger ও balance update server-side transaction-এ করতে হবে।

## বাজেট সম্পর্কে
৳৫,০০০–৳১৫,০০০ দিয়ে prototype/MVP এবং সীমিত পরীক্ষা করা সম্ভব হতে পারে, যদি নিজে কাজ করেন। পেমেন্ট provider, বিজ্ঞাপন অনুমোদন, iOS প্রকাশনা, নকশা, আইনি পর্যালোচনা এবং পরিচালনার খরচ আলাদা হতে পারে। এই ZIP-এর কোড নিজে থেকে আয় বা payout নিশ্চিত করে না।
