# EarnBD production checklist

## Before real users
- [ ] Product model and funded reward source documented
- [ ] Terms of Service and Privacy Policy published
- [ ] Firebase project configured for Android and iOS
- [ ] Firebase Authentication and account deletion flow
- [ ] Firestore security rules tested with emulator
- [ ] Cloud Functions for reward issuance and withdrawals
- [ ] Server-side idempotency and anti-replay controls
- [ ] Rate limiting and abuse detection
- [ ] Admin role protected by server-verified custom claims
- [ ] Withdrawal review queue and audit trail
- [ ] Approved bKash/Nagad merchant/disbursement arrangement
- [ ] Rewarded ad integration compliant with ad network policies
- [ ] No reward granted solely from client-side claims
- [ ] Data retention, support, complaints and reversals process
- [ ] Android release signing and iOS signing configured
- [ ] Accessibility, low-end Android and network failure testing

## Suggested reward ledger states
`pending` -> `approved` -> `credited`
or `pending` -> `rejected`

## Suggested withdrawal states
`requested` -> `under_review` -> `approved` -> `paid`
or `requested` -> `rejected` -> `refunded`

A payout must only be marked `paid` after a trusted provider or administrator confirms it.
